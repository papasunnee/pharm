<?php
$less_variables = array(
	'color'        => '#ff9600',
	'a-color'      => '#ff9600',
	'body-color'   => '#222',
	'border-color' => '#ebebeb',
	'url'     => "'../assets/img/orange'",
);

