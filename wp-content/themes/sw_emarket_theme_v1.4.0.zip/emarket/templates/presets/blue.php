<?php
$less_variables = array(
	'color'        => '#18bcec',
	'a-color'      => '#18bcec',
	'body-color'   => '#222',
	'border-color' => '#ebebeb',
	'url'     => "'../assets/img/blue'",
);

