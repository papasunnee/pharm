<?php
$less_variables = array(
	'color'        => '#ff3c20',
	'a-color'      => '#ff3c20',
	'body-color'   => '#222',
	'border-color' => '#ebebeb',
	'url'     => "'../assets/img/default'",
);

