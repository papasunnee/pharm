<?php
	emarket_blog_listing_check();
?>