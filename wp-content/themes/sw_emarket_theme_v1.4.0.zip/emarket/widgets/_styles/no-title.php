<?php
/**
 * Widget Style: xHtml
 *
 */

$ws['no-title'] = array(
	'before_widget' => '',
	'after_widget' => '',
	'before_title' => '<div style="display:none">',
	'after_title' => '</div>'
);