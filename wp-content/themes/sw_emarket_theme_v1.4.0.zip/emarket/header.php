<?php get_template_part( 'templates/head' ); ?>
<body <?php body_class(); ?>>
<div class="body-wrapper theme-clearfix">
	<div class="body-wrapper-inner">
	<?php emarket_header_check(); ?>